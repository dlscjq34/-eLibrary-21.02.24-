package com.example.e_library.member;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.webkit.CookieManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.e_library.MainActivity;
import com.example.e_library.R;
import com.example.e_library.common.BasicActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Timestamp;

//로그인
public class LoginAct extends BasicActivity {
    EditText etId, etPswd;
    Button btnLogin;
    boolean loginOK = false;
    SharedPreferences sp;
    MemberVO member = new MemberVO();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
        etId = findViewById(R.id.etId);
        etPswd = findViewById(R.id.etPswd);
        btnLogin = findViewById(R.id.btnLogin);
        sp = getSharedPreferences("sFile", MODE_PRIVATE);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //로그인 백그라운드 작업
                new LoginThread().start();

            }//onClick
        });//btnLogin
    }//onCreate







    //로그인 백그라운드 작업
    class LoginThread extends Thread {
        Handler handler = new Handler();

        @Override
        public void run() {
            try {
                //서버 접속 및 데이터 전달
                HttpURLConnection conn = conn("androidLogin");
                String param = "memberId="+etId.getText().toString()+"&pswd="+etPswd.getText().toString();//서버로 갈 로그인 정보
                writeToServer(conn, param);

                //서버로부터 정상 응답 받으면
                if (conn.getResponseCode() == 200) {

                    //꺼내온 데이터를 json 변환
                    JSONObject jsonObj = readFromServer(conn);
                    if (!jsonObj.getString("memberId").equals("empty")) {
                        setMember(jsonObj);
                        getMember();
                        loginOK = true;
                    }

                    //결과 통보
                    if (loginOK) {
                        handlerMessage(handler, "로그인 되었습니다.");
                        finish();
                    }
                    else {
                        handlerMessage(handler, "아이디와 비밀번호를 다시 확인해주세요.");
                    }

                }//if (conn.getResponseCode() == 200)
            }
            catch (Exception e) {
                handlerMessage(handler, e.toString());
            }
        }//run
    }//LoginThread





    //커스텀 메서드///////////////////////////////////////////////////////////////////////////////////////////////////

    //멤버정보 변경
    public void setMember(JSONObject jsonObj) {
        SharedPreferences.Editor editor = sp.edit();
        try {
            editor.putString("memberId", jsonObj.getString("memberId"));
            editor.putString("pswd", jsonObj.getString("pswd"));
            editor.putString("memberName", jsonObj.getString("memberName"));
            editor.putString("addr", jsonObj.getString("addr"));
            editor.putString("tel", jsonObj.getString("tel"));
            editor.putString("regDate", jsonObj.getString("regDate"));
            editor.commit();
        }
        catch (JSONException e) {
            e.printStackTrace();
        }
    }


    //현재 멤버정보
    public void getMember() {
        member.setMemberId(sp.getString("memberId", "empty"));
        member.setPswd(sp.getString("pswd", "empty"));
        member.setMemberName(sp.getString("memberName", "empty"));
        member.setAddr(sp.getString("addr", "empty"));
        member.setTel(sp.getString("tel", "empty"));
        member.setRegDate(sp.getString("regDate", "empty"));
    }
}
