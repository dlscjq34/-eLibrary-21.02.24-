package com.example.e_library;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.CookieManager;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.e_library.Rent.UseHistory;
import com.example.e_library.book.NewBookAct;
import com.example.e_library.book.SearchBookAct;
import com.example.e_library.common.BasicActivity;
import com.example.e_library.favor.FavorListAct;
import com.example.e_library.member.LoginAct;
import com.example.e_library.notice.NoticeAct;
import com.example.e_library.notice.NoticeListAct;
import com.example.e_library.notice.NoticeVO;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.HttpURLConnection;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.Inflater;

public class MainActivity extends BasicActivity {

    TextView noticeContent;
    SharedPreferences sp;
    List<NoticeVO> noticeList = new ArrayList<>();

    //메인액티비티 생성 시
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        noticeContent = findViewById(R.id.noticeContent);

        findViewById(R.id.imgX).setVisibility(View.INVISIBLE);//공통화면에 나오는 창닫기 아이콘 표시 해제
        getNoticeList(); //공지 데이터 받아와서 가장최근꺼 화면에 표시

        //공지내용 클릭 시 상세정보
        noticeContent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), NoticeAct.class);
                intent.putExtra("notice", noticeList.get(0));
                startActivity(intent);
            }
        });


    }

    //공지 데이터 받아와서 화면에 표시
    public void getNoticeList() {

        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    HttpURLConnection conn = conn("androidNoticeList");
                    String param = "TEST=" + "TEST";//서버로 갈 정보
                    writeToServer(conn, param);

                    if (conn.getResponseCode() == 200) {
                        //서버 접속 및 데이터 전달
                        //꺼내온 데이터를 json 변환
                        JSONObject jsonObj = readFromServer(conn);//제이슨객체 생성
                        JSONArray jArray = jsonObj.getJSONArray("result");
                        for (int i = 0; i < jArray.length(); i++) {
                            JSONObject jsonRow = jArray.getJSONObject(i);
                            NoticeVO notice = new NoticeVO();
                            notice.setNoticeId(jsonRow.getString("noticeId"));
                            notice.setRegDate(jsonRow.getString("regDate"));
                            notice.setTitle(jsonRow.getString("title"));
                            notice.setContent(jsonRow.getString("content"));
                            noticeList.add(notice);
                        }
                        conn.disconnect();
                        noticeContent.setText(noticeList.get(0).getTitle());
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }//run
        });
        thread.start();
    }//getNoticeList()



    //프로그램 종료 시 사용자 세션 삭제
    @Override
    protected void onDestroy() {
        super.onDestroy();
        sp = getSharedPreferences("sFile", MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();
        editor.clear();
        editor.commit();
    }

    //옵션 메뉴 선택
    public void onClick(View v) {
        sp = getSharedPreferences("sFile", MODE_PRIVATE);
        boolean isNotLogin = sp.getString("memberId", "empty").equals("empty");
        Intent intent = null;

        switch (v.getId()) {
            case R.id.search:
                intent = new Intent(this, SearchBookAct.class);
                break;
            case R.id.use://로그인 안했으면 로그인창, 아니면 이용내역 이동
                if (isNotLogin)
                    intent = new Intent(this, LoginAct.class);
                else
                    intent = new Intent(this, UseHistory.class);
                break;
            case R.id.favor://로그인 안했으면 로그인창, 아니면 이용내역 이동
                if (isNotLogin)
                    intent = new Intent(this, LoginAct.class);
                else
                    intent = new Intent(this, FavorListAct.class);
                break;
            case R.id.newBook:
                intent = new Intent(this, NewBookAct.class);
                break;
            case R.id.noticeTitle:
                intent = new Intent(this, NoticeListAct.class);
                break;
        }
        startActivity(intent);
    }
}
