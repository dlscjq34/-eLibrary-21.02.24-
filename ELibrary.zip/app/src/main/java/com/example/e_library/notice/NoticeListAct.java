package com.example.e_library.notice;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.e_library.R;
import com.example.e_library.book.BookInfoAct;
import com.example.e_library.book.BookVO;
import com.example.e_library.book.NewBookAct;
import com.example.e_library.common.BasicActivity;
import com.example.e_library.common.DTO;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

public class NoticeListAct extends BasicActivity {

    ListView lvNoticeList;
    List<NoticeVO> noticeList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.notice_list);
        lvNoticeList = findViewById(R.id.lvNoticeList);

        new NoticeListThread().start();
    }


    //공지사항 백그라운드작업
    public class NoticeListThread extends Thread {
        Handler handler = new Handler();

        @Override
        public void run() {

            try {
                //서버 접속 및 데이터 전달
                HttpURLConnection conn = conn("androidNoticeList");
                String param = "TEST=" + "TEST";//서버로 갈 정보
                writeToServer(conn, param);

                //서버로부터 정상 응답 받으면
                if (conn.getResponseCode() == 200) {

                    //꺼내온 데이터를 json 변환
                    JSONObject jsonObj = readFromServer(conn);//제이슨객체 생성
                    JSONArray jArray = jsonObj.getJSONArray("result");
                    for (int i = 0; i < jArray.length(); i++) {
                        JSONObject jsonRow = jArray.getJSONObject(i);
                        NoticeVO notice = new NoticeVO();
                        notice.setNoticeId(jsonRow.getString("noticeId"));
                        notice.setRegDate(jsonRow.getString("regDate"));
                        notice.setTitle(jsonRow.getString("title"));
                        notice.setContent(jsonRow.getString("content"));
                        noticeList.add(notice);
                    }
                    conn.disconnect();

                    //화면 변경
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            NoticeListAdapter adapter = new NoticeListAdapter(NoticeListAct.this, R.layout.common_book_row, noticeList);
                            lvNoticeList.setAdapter(adapter);

                            lvNoticeList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                                @Override
                                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                                    Intent intent = new Intent(getApplicationContext(), NoticeAct.class);
                                    intent.putExtra("notice", noticeList.get(position));
                                    startActivity(intent);
                                }
                            });
                        }
                    });
                }//if (conn.getResponseCode() == 200)
            }
            catch (Exception e) {
                handlerMessage(handler, e.toString());
            }
        }//run
    }//NewBookListThread





    //커스텀 어댑터
    class NoticeListAdapter extends ArrayAdapter<NoticeVO> {

        public NoticeListAdapter(@NonNull Context context, int resource, @NonNull List<NoticeVO> objects) {
            super(context, resource, objects);
        }

        //자식뷰 생산
        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

            View v = convertView;

            if (v == null) {//처음 한번만 실행
                LayoutInflater li = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);//뷰생성기
                v = li.inflate(R.layout.notice_list_row, null);//자식뷰 생성
            }

            //자식뷰에 데이터 투입
            NoticeVO notice = noticeList.get(position);
            if (notice != null) {
                TextView tvNoticeTitle = v.findViewById(R.id.tvNoticeTitle);
                TextView tvNoticeDate = v.findViewById(R.id.tvNoticeDate);

                tvNoticeTitle.setText(notice.getTitle());
                tvNoticeDate.setText(notice.getRegDate());
            }
            return v;
        }
    }//UseHistoryAdapter
}