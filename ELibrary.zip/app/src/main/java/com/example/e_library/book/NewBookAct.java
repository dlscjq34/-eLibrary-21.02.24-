package com.example.e_library.book;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.e_library.R;
import com.example.e_library.common.BasicActivity;
import com.example.e_library.favor.FavorListAct;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class NewBookAct extends BasicActivity {

    ListView lvNewBook;
    List<BookVO> newBookList = new ArrayList<>();//신간 리스트

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.new_book);
        lvNewBook = findViewById(R.id.lvNewBook);

        new NewBookListThread().start();//신간도서 백그라운드작업
    }




    //신간도서 백그라운드작업
    class NewBookListThread extends Thread {
        Handler handler = new Handler();

        @Override
        public void run() {
            try {
                //서버 접속 및 데이터 전달
                HttpURLConnection conn = conn("androidNewBook");
                String param = "TEST="+"TEST";//서버로 갈 정보
                writeToServer(conn, param);

                //서버로부터 정상 응답 받으면
                if (conn.getResponseCode() == 200) {

                    //꺼내온 데이터를 json 변환
                    JSONObject jsonObj = readFromServer(conn);//제이슨객체 생성
                    JSONArray jArray = jsonObj.getJSONArray("result");
                    for (int i = 0; i < jArray.length(); i++) {
                        JSONObject jsonRow = jArray.getJSONObject(i);
                        BookVO book = new BookVO();
                        book.setBookId(jsonRow.getString("bookId"));
                        book.setBookName(jsonRow.getString("bookName"));
                        book.setWriter(jsonRow.getString("writer"));
                        book.setPublisher(jsonRow.getString("publisher"));
                        book.setPubliDate(jsonRow.getString("publiDate"));
                        book.setStatus(jsonRow.getString("status"));
                        newBookList.add(book);
                    }
                    conn.disconnect();

                    //결과 화면
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            NewBookListAdapter adapter = new NewBookListAdapter(NewBookAct.this, R.layout.common_book_row, newBookList);
                            lvNewBook.setAdapter(adapter);
                        }
                    });
                }//if (conn.getResponseCode() == 200)
            }
            catch (Exception e) {
                handlerMessage(handler, e.toString());
            }
        }//run
    }//NewBookListThread








    //커스텀 어댑터
    class NewBookListAdapter extends ArrayAdapter<BookVO> {

        public NewBookListAdapter(@NonNull Context context, int resource, @NonNull List<BookVO> objects) {
            super(context, resource, objects);
        }

        //자식뷰 생산
        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

            View v = convertView;

            if (v == null) {//처음 한번만 실행
                LayoutInflater li = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);//뷰생성기
                v = li.inflate(R.layout.common_book_row, null);//자식뷰 생성
            }

            //자식뷰에 데이터 투입
            BookVO bookVO = newBookList.get(position);
            if (bookVO != null) {
                TextView bookName = v.findViewById(R.id.bookName);
                TextView writer = v.findViewById(R.id.writer);
                TextView publisher = v.findViewById(R.id.publisher);
                TextView publiDate = v.findViewById(R.id.publiDate);
                TextView status = v.findViewById(R.id.status);
                TextView bookId = v.findViewById(R.id.bookId);

                bookName.setText(bookVO.getBookName());
                writer.setText("저자 : "+bookVO.getWriter());
                publisher.setText("출판사 : "+bookVO.getPublisher());
                publiDate.setText("발간일 : "+bookVO.getPubliDate());
                status.setText("상태 : "+bookVO.getStatus());
                bookId.setText("도서번호 : "+bookVO.getBookId());
            }

            return  v;
        }
    }
}