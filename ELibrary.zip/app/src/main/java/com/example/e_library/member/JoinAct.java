package com.example.e_library.member;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.e_library.MainActivity;
import com.example.e_library.R;
import com.example.e_library.common.BasicActivity;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

//회원 가입
public class JoinAct extends BasicActivity {

    EditText etId, etPswd, etMemberName, etAddr, etTel;
    Button btnJoin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.join);

        etId = findViewById(R.id.etId);
        etPswd = findViewById(R.id.etPswd);
        etMemberName = findViewById(R.id.etMemberName);
        etAddr = findViewById(R.id.etAddr);
        etTel = findViewById(R.id.etTel);
        btnJoin = findViewById(R.id.btnJoin);

        btnJoin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //회원정보 유효성 검사
                if (etId.getText().length() < 5) {
                    Toast.makeText(JoinAct.this, "아이디를 5자리 이상 입력하세요", Toast.LENGTH_SHORT).show();
                    return;
                }
                else if (etPswd.getText().length() < 5) {
                    Toast.makeText(JoinAct.this, "비밀번호를 5자리 이상 입력하세요", Toast.LENGTH_SHORT).show();
                    return;
                }
                else if (etMemberName.getText().toString().equals("") || etAddr.getText().toString().equals("") || etTel.getText().toString().equals("")) {
                    Toast.makeText(JoinAct.this, "빈 칸에 내용을 입력해주세요.", Toast.LENGTH_SHORT).show();
                }


                //회원가입 백그라운드작업
                new JoinThread().start();

            }//onClick
        });//btnLogin
    }//onCreate






    //회원가입 백그라운드작업
    class JoinThread extends Thread {
        Handler handler = new Handler();

        @Override
        public void run() {
            try {
                //서버 접속 및 데이터 전달
                HttpURLConnection conn = conn("androidJoin");
                String param = "memberId="+etId.getText().toString()+
                        "&pswd="+etPswd.getText().toString()+
                        "&memberName="+etMemberName.getText().toString()+
                        "&addr="+etAddr.getText().toString()+
                        "&tel="+etTel.getText().toString();//서버로 갈 정보
                writeToServer(conn, param);

                //서버로부터 정상 응답 받으면
                if (conn.getResponseCode() == 200) {

                    //꺼내온 데이터를 json 변환
                    JSONObject jsonObj = readFromServer(conn);
                    String result = jsonObj.getString("result");
                    conn.disconnect();

                    //결과 통보
                    handlerMessage(handler, result);
                    if (result.equals("회원가입 되었습니다."))
                        finish();

                }
            }
            catch (Exception e) {
                handlerMessage(handler, e.toString());
            }
        }//run
    }//JoinThread
}