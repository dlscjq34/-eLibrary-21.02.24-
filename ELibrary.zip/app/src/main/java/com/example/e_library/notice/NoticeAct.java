package com.example.e_library.notice;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.e_library.R;
import com.example.e_library.common.BasicActivity;

public class NoticeAct extends BasicActivity {

    TextView noticeTitle, noticeContent, noticeId, noticeRegDate;
    Button btnNoticeList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.notice);
        noticeTitle = findViewById(R.id.noticeTitle);
        noticeContent = findViewById(R.id.noticeContent);
        noticeId = findViewById(R.id.noticeId);
        noticeRegDate = findViewById(R.id.noticeRegDate);
        btnNoticeList = findViewById(R.id.btnNoticeList);

        NoticeVO notice = (NoticeVO) getIntent().getSerializableExtra("notice");
        noticeTitle.setText("- "+notice.getTitle()+" -");
        noticeContent.setText(notice.getContent());
        noticeId.setText("공지번호 : "+notice.getNoticeId());
        noticeRegDate.setText("공지일 : "+notice.getRegDate());

        btnNoticeList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), NoticeListAct.class);
                startActivity(intent);
                finish();
            }
        });
    }
}