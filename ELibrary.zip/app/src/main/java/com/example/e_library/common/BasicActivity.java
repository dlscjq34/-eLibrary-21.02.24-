package com.example.e_library.common;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.e_library.Rent.UseHistory;
import com.example.e_library.book.BookInfoAct;
import com.example.e_library.book.NewBookAct;
import com.example.e_library.favor.FavorListAct;
import com.example.e_library.member.JoinAct;
import com.example.e_library.member.LoginAct;
import com.example.e_library.MainActivity;
import com.example.e_library.R;
import com.example.e_library.book.SearchBookAct;
import com.example.e_library.member.MemberAct;
import com.example.e_library.notice.NoticeListAct;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.logging.ConsoleHandler;
import java.util.logging.LogRecord;

//공통 메뉴
public class BasicActivity extends AppCompatActivity {

    Intent basicIntent = null;


    //서버 접속 객체
    public HttpURLConnection conn(String server) {

        HttpURLConnection conn = null;
        String ipAddress = "http://192.168.49.32:8080/";
        String serverAddress = ipAddress+server;

        try {
            URL url = new URL(serverAddress);
            conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(5000);
            conn.setRequestMethod("POST");
            conn.setUseCaches(false);
        }
        catch (Exception e) {
            Toast.makeText(getApplicationContext(), "ERROR : "+e.toString(), Toast.LENGTH_SHORT).show();
        }

        return conn;
    }



    //서버로 데이터 보내기
    public void writeToServer(HttpURLConnection conn, String param) {

        try {
            OutputStream os = conn.getOutputStream();//접속객체에서 출력스트림 만들어서
            byte[] bytes = param.getBytes("UTF-8");//로그인 정보를 바이트배열에 담고
            os.write(bytes);//출력스트림에 바이트배열을 담자 (전송 완료)
            os.close();
        }
        catch (Exception e) {
            Toast.makeText(getApplicationContext(), "ERROR : "+e.toString(), Toast.LENGTH_SHORT).show();
        }
    }



    //서버가 준 데이터를 json 객체로 받기
    public JSONObject readFromServer(HttpURLConnection conn) {

        StringBuilder sb = new StringBuilder();
        InputStream is = null;//서버에서 자료 받을 입력스트림
        JSONObject jsonObj = null;

        try {
            is = conn.getInputStream();
            InputStreamReader isr = new InputStreamReader(is, "utf-8");//한글처리
            BufferedReader br = new BufferedReader(isr);//성능

            //리더에서 데이터 꺼내오고 리더 및 접속 닫기
            while (true) {
                String line = br.readLine();
                if (line == null) break;
                sb.append(line+"\n");
            }
            br.close();
            isr.close();
            is.close();

            //꺼내온 데이터를 json 변환
            jsonObj = new JSONObject(sb.toString());
        }
        catch (Exception e) {
            Toast.makeText(getApplicationContext(), "ERROR : "+e.toString(), Toast.LENGTH_SHORT).show();
        }

        return jsonObj;
    }


    //스레드 내 메시지
    public void handlerMessage(Handler handler, String message) {
        handler.post(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
            }
        });


    }


    //옵션메뉴 생성 시
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        MenuInflater menuInflater = getMenuInflater();//메뉴생성기
        menuInflater.inflate(R.menu.main_menu, menu);//메뉴 생성
        return true;
    }



    //세션 유무에 따른 옵션메뉴 표현범위
    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        SharedPreferences sp = getSharedPreferences("sFile",MODE_PRIVATE);
        String session = sp.getString("memberId","empty");
        if (session.equals("empty")) {//세션이 없으면
            menu.findItem(R.id.login).setVisible(true);
            menu.findItem(R.id.logOut).setVisible(false);
            menu.findItem(R.id.join).setVisible(true);
            menu.findItem(R.id.useHistory).setVisible(false);
            menu.findItem(R.id.favorBook).setVisible(false);
            menu.findItem(R.id.member).setVisible(false);
        }
        else {
            menu.findItem(R.id.login).setVisible(false);
            menu.findItem(R.id.logOut).setVisible(true);
            menu.findItem(R.id.join).setVisible(false);
            menu.findItem(R.id.useHistory).setVisible(true);
            menu.findItem(R.id.favorBook).setVisible(true);
            menu.findItem(R.id.member).setVisible(true);
        }
        return true;
    }



    //옵션메뉴 선택 시
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId()) {
            case R.id.login:
                basicIntent = new Intent(this, LoginAct.class);
                break;
            case R.id.logOut:
                new AlertDialog.Builder(BasicActivity.this)
                        .setTitle("로그아웃")
                        .setMessage("로그 아웃하시겠습니까?")
                        .setPositiveButton("예", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                SharedPreferences sp = getSharedPreferences("sFile", MODE_PRIVATE);
                                SharedPreferences.Editor editor = sp.edit();
                                editor.clear();
                                editor.commit();
                                Toast.makeText(BasicActivity.this, "로그아웃 되었습니다.", Toast.LENGTH_SHORT).show();
                                basicIntent = new Intent(getApplicationContext(), MainActivity.class);// 첫번째 액티비티로 인탠트를 설정
                                startActivity(basicIntent);// 액티비티를 실행한다
                                finish();// 현재 액티비티를 종료한다.
                            }
                        })
                        .setNegativeButton("아니오", null)
                        .show();
                return false;
            case R.id.join:
                basicIntent = new Intent(this, JoinAct.class);
                break;
            case R.id.search:
                basicIntent = new Intent(this, SearchBookAct.class);
                break;
            case R.id.useHistory:
                basicIntent = new Intent(this, UseHistory.class);
                break;
            case R.id.member:
                basicIntent = new Intent(this, MemberAct.class);
                break;
            case R.id.favorBook:
                basicIntent = new Intent(this, FavorListAct.class);
                break;
            case R.id.newBook:
                basicIntent = new Intent(this, NewBookAct.class);
                break;
            case R.id.notice:
                basicIntent = new Intent(this, NoticeListAct.class);
                break;
        }
        startActivity(basicIntent);
        return false;
    }



    //홈으로 및 현재창 종료
    public void headerOnClick(View v) {
        switch (v.getId()) {
            case R.id.header:
                basicIntent = new Intent(this, MainActivity.class);// 첫번째 액티비티로 인탠트를 설정
                basicIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);// 스택에 남아있는 중간 액티비티 삭제
                basicIntent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);// 스택에 남아있는 액티비티라면, 재사용
                startActivity(basicIntent);// 액티비티를 실행한다
                finish();// 현재 액티비티를 종료한다.

            case R.id.imgX:
                finish();// 현재 액티비티를 종료한다.
        }
    }
}
